// ═══════════════════════════════════════════════════════════════
//  KHO ẢNH CỦA GAME  —  chỉ cần sửa file này khi muốn đổi ảnh/tên
//  Ảnh nằm trong thư mục  images/  của repo (không dùng web ngoài).
//  Muốn thay ảnh: giữ NGUYÊN tên file, tải đè lên GitHub là xong.
// ═══════════════════════════════════════════════════════════════
window.GAME_IMAGES = {
    folder: 'images/',

    // Ảnh đại diện nhân vật (ở sảnh chờ, màn chọn thân phận, bảng xếp hạng)
    avatars: {
        gambler:  'avatars/gambler.webp',   // Con Bạc
        madman:   'avatars/madman.webp',    // Gã Điên
        fool:     'avatars/fool.webp',      // Gã Khờ
        guard:    'avatars/guard.webp',     // Bảo Vệ
        scholar:  'avatars/scholar.webp',   // Học Bá
        doraemon: 'avatars/doraemon.webp',  // Doraemon
        random:   'avatars/random.webp'     // Random
    },

    // 15 quái thường (phòng 1,2,3... lần lượt, hết vòng thì quay lại).
    // hue = xoay màu (độ) để tạo bản "biến dị" từ cùng 1 ảnh, 0 = giữ nguyên.
    monsters: [
        { file: 'monsters/monster-01.webp', name: 'Tiểu Quỷ Mũ Len',          aura: 'rgba(251,146,60,0.45)' },
        { file: 'monsters/monster-02.webp', name: 'Yêu Lông Đen Sừng Cong',   aura: 'rgba(148,163,184,0.45)' },
        { file: 'monsters/monster-03.webp', name: 'Yêu Lông Xanh Biển',       aura: 'rgba(56,189,248,0.5)' },
        { file: 'monsters/monster-04.webp', name: 'Quái Hồng Cười Toe',       aura: 'rgba(236,72,153,0.45)' },
        { file: 'monsters/monster-05.webp', name: 'Quái Lông Vàng Tinh Nghịch', aura: 'rgba(250,204,21,0.5)' },
        { file: 'monsters/monster-06.webp', name: 'Quái Đỏ Gầm Gừ',           aura: 'rgba(239,68,68,0.5)' },
        { file: 'monsters/monster-07.webp', name: 'Quái Hồng Điện Giật',      aura: 'rgba(217,70,239,0.5)' },
        { file: 'monsters/monster-08.webp', name: 'Quái Xanh Ngọc Ngồi Bệt',  aura: 'rgba(34,211,238,0.5)' },
        { file: 'monsters/monster-09.webp', name: 'Quái Tím Răng Nanh',       aura: 'rgba(168,85,247,0.5)' },
        { file: 'monsters/monster-10.webp', name: 'Tiểu Long Xanh Gai',       aura: 'rgba(16,185,129,0.5)' },
        { file: 'monsters/monster-11.webp', name: 'Quái Một Mắt Lè Lưỡi',     aura: 'rgba(59,130,246,0.5)' },
        { file: 'monsters/monster-12.webp', name: 'Quái Mèo Một Mắt',         aura: 'rgba(251,113,133,0.5)' },
        { file: 'monsters/monster-13.webp', name: 'Quỷ Xanh Dương Hai Tay',   aura: 'rgba(14,165,233,0.5)' },
        { file: 'monsters/monster-01.webp', name: 'Tiểu Quỷ Mũ Len Biến Dị',  aura: 'rgba(34,197,94,0.5)',  hue: 90 },
        { file: 'monsters/monster-09.webp', name: 'Quái Răng Nanh Biến Dị',   aura: 'rgba(14,165,233,0.5)', hue: 140 }
    ],

    // 5 boss (phòng 10, 20, 30... lần lượt). Tên boss nằm ở 04-monster-name-table-fix.js
    bossFile: 'monsters/boss.webp',
    bosses: [
        { aura: 'rgba(255,0,0,0.7)',     hue: 300 },
        { aura: 'rgba(0,240,255,0.7)',   hue: 150 },
        { aura: 'rgba(34,211,238,0.6)',  hue: 190 },
        { aura: 'rgba(168,85,247,0.7)',  hue: 0 },
        { aura: 'rgba(234,88,12,0.8)',   hue: 60 }
    ],

    // Icon trang bị: dùng emoji (không cần file). Muốn dùng ảnh riêng thì ghi
    // đường dẫn file, ví dụ  pistol: 'items/pistol.webp'
    items: {
        short_sword: '⚔️', fishing_rod: '🎣', pistol: '🔫', cursed_mask: '🎭',
        ocean_heart: '💙', lucky_star: '⭐', pumpkin: '🎃'
    }
};
